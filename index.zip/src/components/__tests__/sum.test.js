import { Sum } from "../sum";

test("Sum of two positive number", () => {
  expect(Sum(2, 3)).toBe(5);
});
