export const Sum = (a, b) => a + b;
